// admin.js
const bcrypt = require('bcryptjs');
const connection = require('./db');

module.exports = function (app) {
  // Registrar administrador
  app.post('/register', async (req, res) => {
    console.log('Registro recibido:', req.body);
    const { nombre, correo, contrasena } = req.body;

    if (!nombre || !correo || !contrasena) {
      return res.status(400).json({ message: 'Todos los campos son obligatorios' });
    }

    try {
      const hashedPass = await bcrypt.hash(contrasena, 10);

      connection.query(
        'INSERT INTO administradores (nombre, correo, contrasena) VALUES (?, ?, ?)',
        [nombre, correo, hashedPass],
        (err, result) => {
          if (err) {
            console.error(err);
            return res.status(500).json({ message: 'Error al registrar administrador' });
          }
          res.json({ message: 'Administrador registrado exitosamente' });
        }
      );
    } catch (err) {
      console.error(err);
      return res.status(500).json({ message: 'Error al hashear la contraseña' });
    }
  });

  // Login de administrador
  app.post('/login', (req, res) => {
    const { correo, contrasena } = req.body;

    connection.query('SELECT * FROM administradores WHERE correo = ?', [correo], async (err, results) => {
      if (err) return res.status(500).json({ message: 'Error en el servidor' });

      if (results.length === 0) {
        return res.status(401).json({ message: 'Correo no encontrado' });
      }

      const admin = results[0];
      const match = await bcrypt.compare(contrasena, admin.contrasena);

      if (!match) {
        return res.status(401).json({ message: 'Contraseña incorrecta' });
      }

      req.session.admin = {
    id: admin.id,
    nombre: admin.nombre,
    correo: admin.correo
      };
 
      res.json({ message: 'Login exitoso', admin: { id: admin.id, nombre: admin.nombre } });
    });
  

  });

};
