
const connection = require('./db');
module.exports = (app, connection, bcrypt) => {


  app.post('/pacientes', async (req, res) => {
    console.log('Registro recibido:', req.body);
    const { nombre, correo, contrasena } = req.body;

    if (!nombre || !correo || !contrasena) {
      return res.status(400).json({ message: 'Todos los campos son obligatorios' });
    }

    try {
      const hashedPass = await bcrypt.hash(contrasena, 10);

      connection.query(
        'INSERT INTO administradores (nombre, correo, contrasena) VALUES (?, ?, ?)',
        [nombre, correo, hashedPass],
        (err, result) => {
          if (err) {
            console.error(err);
            return res.status(500).json({ message: 'Error al registrar administrador' });
          }
          res.json({ message: 'Administrador registrado exitosamente' });
        }
      );
    } catch (err) {
      console.error(err);
      return res.status(500).json({ message: 'Error al hashear la contraseña' });
    }
  });


};