const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcrypt');
require('dotenv').config();

module.exports = function(app) {
  const transporter = require('nodemailer').createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS
    }
  });

  // Ruta para enviar enlace de recuperación
  app.post('/recuperar', (req, res) => {
    const { correo } = req.body;

    // Buscar usuario en la base de datos
    connection.query('SELECT * FROM administradores WHERE correo = ?', [correo], (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'Error interno en la base de datos' });
      }

      if (results.length === 0) {
        return res.status(404).json({ message: 'Correo no registrado' });
      }

      const token = uuidv4();
      const expira = Date.now() + 3600000; // 1 hora en ms

      // Guardar token y expiración en BD
      connection.query(
        'UPDATE administradores SET token_recuperacion = ?, token_expira = ? WHERE correo = ?',
        [token, expira, correo],
        (err) => {
          if (err) {
            console.error(err);
            return res.status(500).json({ message: 'Error guardando token' });
          }

          const link = `http://localhost:3000/restablecer.html?token=${token}`;
          const mailOptions = {
            from: process.env.EMAIL_USER,
            to: correo,
            subject: 'Recuperación de contraseña',
            html: `
              <p>Haz clic en este enlace para restablecer tu contraseña:</p>
              <a href="${link}">${link}</a>
              <p>Si no solicitaste esta acción, ignora este correo.</p>
            `
          };

          transporter.sendMail(mailOptions, (err, info) => {
            if (err) {
              console.error(err);
              return res.status(500).json({ message: 'Error enviando correo' });
            }

            res.json({ message: 'Enlace de recuperación enviado al correo' });
          });
        }
      );
    });
  });

  // Ruta para restablecer contraseña
  app.post('/restablecer', (req, res) => {
    const { token, nueva } = req.body;

    // Buscar usuario con token válido
    connection.query(
      'SELECT * FROM administradores WHERE token_recuperacion = ? AND token_expira > ?',
      [token, Date.now()],
      (err, results) => {
        if (err) {
          console.error(err);
          return res.status(500).json({ message: 'Error en la base de datos' });
        }

        if (results.length === 0) {
          return res.status(400).json({ message: 'Token inválido o expirado' });
        }

        // Hashear la nueva contraseña
        const saltRounds = 10;
        bcrypt.hash(nueva, saltRounds, (err, hash) => {
          if (err) {
            console.error(err);
            return res.status(500).json({ message: 'Error procesando la contraseña' });
          }

          // Actualizar contraseña y borrar token
          connection.query(
            'UPDATE administradores SET contrasena = ?, token_recuperacion = NULL, token_expira = NULL WHERE token_recuperacion = ?',
            [hash, token],
            (err) => {
              if (err) {
                console.error(err);
                return res.status(500).json({ message: 'Error actualizando contraseña' });
              }

              res.json({ message: 'Contraseña restablecida correctamente' });
            }
          );
        });
      }
    );
  });
};
