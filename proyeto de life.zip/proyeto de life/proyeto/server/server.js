const express = require('express');
const path = require('path');
const session = require('express-session');


const app = express();
const PORT = 3000;

// Middleware para leer JSON
app.use(express.json());

// Configuración de sesiones
app.use(session({
  secret: 'mi_secreto_seguro',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } // No activar "secure" en desarrollo local
}));


// **Servir archivos estáticos desde la carpeta "public"**
app.use(express.static(path.join(__dirname, '..', 'public')));

// **Conexión a la base de datos**
global.connection = require('./db');

// **Rutas API**
 require('./admin')(app); 
 require('./correo')(app); 

// **Iniciar servidor**
app.listen(3000, () => {
  console.log('Servidor corriendo en http://localhost:3000');
});

