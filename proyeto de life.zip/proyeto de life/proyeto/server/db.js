// db.js
const mysql = require('mysql2');

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '', // pon tu contraseña si tienes
  database: 'gestion_salud'
});

db.connect((err) => {
  if (err) {
    console.error('🔴 Error al conectar con MySQL:', err.message);
    return;
  }
  console.log('🟢 Conectado a MySQL');
});

module.exports = db;
