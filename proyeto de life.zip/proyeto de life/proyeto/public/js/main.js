document.getElementById('adminForm').addEventListener('submit', async function (e) {
  e.preventDefault();

  const nombre = document.getElementById('nombre').value.trim();
  const correo = document.getElementById('correo').value.trim();
  const contrasena = document.getElementById('contrasena').value.trim();

  if (!nombre || !correo || !contrasena) {
    alert('Todos los campos son obligatorios.');
    return;
  }

  try {
    const response = await fetch('/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ nombre, correo, contrasena })
    });

    const result = await response.json();

    if (response.ok) {
      alert(result.message);
      // Puedes redirigir al login si quieres:
        window.location.href = 'login.html';
    } else {
      alert(`Error: ${result.message}`);
    }
  } catch (error) {
    console.error('Error al registrar administrador:', error);
    alert('Hubo un error al conectarse con el servidor.');
  }
});
