// Verificar sesión
const admin = localStorage.getItem('admin');
if (!admin) {
  window.location.href = 'login.html';
}

// Cerrar sesión
document.getElementById('logoutBtn').addEventListener('click', () => {
  localStorage.removeItem('admin');
  window.location.href = 'login.html';
});

// Cargar formularios al hacer clic en el menú
document.querySelectorAll('.sidebar a').forEach(link => {
  link.addEventListener('click', async e => {
    e.preventDefault();
    const formPath = link.getAttribute('data-form');
    const res = await fetch(formPath);
    if (res.ok) {
      const html = await res.text();
      document.getElementById('formContainer').innerHTML = html;
    } else {
      document.getElementById('formContainer').innerHTML = '<p>Error al cargar el formulario.</p>';
    }
  });
});
