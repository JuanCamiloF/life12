document.getElementById('loginForm').addEventListener('submit', async function (e) {
  e.preventDefault();

  const correo = document.getElementById('correo').value.trim();
  const contrasena = document.getElementById('contrasena').value.trim();

  if (!correo || !contrasena) {
    alert('Por favor, ingrese correo y contraseña.');
    return;
  }

  try {
    const res = await fetch('/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ correo, contrasena })
    });

    const data = await res.json();

    if (res.ok) {
      alert('Bienvenido');
      localStorage.setItem('admin', JSON.stringify(data.admin));  // Aquí guardamos el admin
      window.location.href = "dashboard.html"; // Redirige al dashboard
    } else {
      alert(data.message || 'Credenciales incorrectas');
    }
  } catch (error) {
    console.error('Error de red:', error);
    alert('Error de conexión con el servidor.');
  }
});
